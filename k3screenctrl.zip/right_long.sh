#!/bin/sh

# check the output with the command logread -f
logger right key long pressed on page $1
