#/bin/bash

echo 深圳市
echo 11
date +%Y-%m-%d
date +%H:%M
echo 25
echo 0
echo 0

