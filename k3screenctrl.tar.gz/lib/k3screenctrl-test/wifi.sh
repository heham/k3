#!/bin/sh
echo 0
echo LEDE-24G
echo password24
echo 1
echo 0
echo LEDE-5G
echo password5
echo 1
echo 4
echo
echo
echo 0
echo 0