#!/bin/sh
echo 2
echo MyHost1
echo 231321
echo 6781231
echo 25
echo MyHost2
echo 237812
echo 2934821
echo 0