#!/bin/sh
echo 1
echo 1
echo 0
echo 1
echo 1