#!/bin/sh
echo 1
echo 10240000
echo 2048000