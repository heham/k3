#!/bin/sh
echo K12345678
echo Awertyuio
echo r1234
echo r4567
echo 01:02:03:04:05:06
