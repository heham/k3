#!/bin/sh

logger left key long pressed on page $1
